from cgd.cli_main import cgd


if __name__ == "__main__":
    cgd()
